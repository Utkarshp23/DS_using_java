/**
 * 
 */
/**
 * @author admin
 *
 */
module strings001 {
}