package booksLL;

public class Node {
	
	public Book data;
	public Node next;
	
	public Node(Book d)
	{
		data=d;
		next=null;
	}
	
	
}
